﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Xml;

namespace GetWorkerSample
{
    class Program
    {
        static void Main(string[] args)
        {

            SecurityBindingElement sb = SecurityBindingElement.CreateUserNameOverTransportBindingElement();
            sb.IncludeTimestamp = false;
            const int lim = Int32.MaxValue;
            var timeout = TimeSpan.FromMinutes(5);

            var cb = new CustomBinding(
                sb,
                new TextMessageEncodingBindingElement(MessageVersion.Soap11, Encoding.UTF8)
                {
                    ReaderQuotas = new XmlDictionaryReaderQuotas
                    {
                        MaxDepth = lim,
                        MaxStringContentLength = lim,
                        MaxArrayLength = lim,
                        MaxBytesPerRead = lim,
                        MaxNameTableCharCount = lim
                    }
                },
                new HttpsTransportBindingElement
                {
                    MaxBufferPoolSize = lim,
                    MaxReceivedMessageSize = lim,
                    MaxBufferSize = lim,
                    Realm = string.Empty
                })
            {
                SendTimeout = timeout,
                ReceiveTimeout = timeout
            };


            Resource_ManagementPortClient RCM = new Resource_ManagementPortClient(cb,new EndpointAddress("https://wd2-impl-services1.workday.com/ccx/service/leggmason8/Resource_Management/v33.1"));

            //RCM.Endpoint.Address = new EndpointAddress("https://wd2-impl-services1.workday.com/ccx/service/leggmason8/Resource_Management/v33.1");

            //Specify the username and password for
             RCM.ClientCredentials.UserName.UserName = "ISU_INT396_WAM_Supplier_Invoices_Inbound@leggmason8";
             RCM.ClientCredentials.UserName.Password = "9DOT44RUN384t";

            #region Stracturung Coeas per workday
            CompanyObjectIDType[] cid = new CompanyObjectIDType[1];
            cid[0] = new CompanyObjectIDType { type = "Company_Reference_ID", Value = "327" };

            CurrencyObjectIDType[] currencyid = new CurrencyObjectIDType[1] { new CurrencyObjectIDType { type = "Currency_ID", Value = "USD" } };
           // Supplier_Invoice_RequestObjectIDType supplerrid = new Supplier_Invoice_RequestObjectIDType { new Supplier_Invoice_RequestObjectIDType { type = "Supplier_ID", Value = "S-0000006695" } };
            Payment_TermsObjectIDType[] paymentTerm = new Payment_TermsObjectIDType[1] { new Payment_TermsObjectIDType { type = "Payment_Terms_ID", Value = "NET0DAYS" } };

            Spend_CategoryObjectType catobjtype = new Spend_CategoryObjectType()
            {
                ID = new Spend_CategoryObjectIDType[]{ new Spend_CategoryObjectIDType {

                      type="Spend_Category_ID",
                      Value="SC0374"
                 } }
            };

            Audited_Accounting_WorktagObjectIDType[] worktagobj =
                new Audited_Accounting_WorktagObjectIDType[]{ new Audited_Accounting_WorktagObjectIDType {  
                     type="Cost_Center_Reference_ID",
                    Value="W5310"

                 }};


            Supplier_Invoice_DataType sisd = new Supplier_Invoice_DataType();

            sisd.Submit = true;
            sisd.Company_Reference = new CompanyObjectType() { ID = cid };
            sisd.Currency_Reference = new CurrencyObjectType() { ID = currencyid.ToArray() };
            //sisd.Supplier_Invoice_Request_Reference = new Supplier_Invoice_RequestObjectType() { ID = supplerrid.ToArray() };
            sisd.Invoice_Date = DateTime.UtcNow;
            sisd.Control_Amount_Total = 4.7M;
            //sisd.Suppliers_Invoice_Number = "SupplierInvoiceNumber000020";
            sisd.Payment_Terms_Reference = new Payment_TermsObjectType() { ID = paymentTerm.ToArray() };
            sisd.Invoice_Line_Replacement_Data = new Supplier_Invoice_Line_Replacement_DataType[] { new Supplier_Invoice_Line_Replacement_DataType {
                 Extended_Amount=1234.56M,
                 Spend_Category_Reference= catobjtype //,
                 //Worktags_Reference = worktagobj

            } };

             #endregion

            //Instantiate Header for the request
            //Workday_Common_HeaderType header = new Workday_Common_HeaderType();
            //header.Include_Reference_Descriptors_In_Response = false;
            //header.Include_Reference_Descriptors_In_ResponseSpecified = false;

            Submit_Supplier_Invoice_RequestType SSIR = new Submit_Supplier_Invoice_RequestType();
            //  SSIR.Business_Process_Parameters = new Financials_Business_Process_ParametersType() { Auto_Complete = false };
            SSIR.Supplier_Invoice_Data = sisd;
            SSIR.Business_Process_Parameters = new Financials_Business_Process_ParametersType() { Auto_Complete = false };
            SSIR.Add_Only = true;
            SSIR.version = "V33.0";
            //Asset_Depreciation_Detail_Line_DataType
            //InnerException = { "There was an error reflecting property 'Exceptions_Response_Data'."}
            //  Exception_DataType
            // Submit_Supplier_Contract_Amendment_Response obj = new Submit_Supplier_Contract_Amendment_Response();
            //  InnerException = { "There was an error reflecting property 'Exceptions_Response_Data'."}

            // Exceptions_Response_Data.

            #region Save to workday
            try
            {
                var objres = RCM.Submit_Supplier_Invoice(SSIR);
            }
            catch (Exception ex)
            {

                throw ex;
            }
            #endregion

        }
    }
}
